xsharp's format is:
format x {y ... z} where x, y, z are cubes.

Christos Vasileiou 1983
